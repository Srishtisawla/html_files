
var makeModelInfo = {
	"Ashok Leyland": ["Stile"], 
"Audi": ["A3", "A4", "A6", "A7", "A8", "Q3", "Q5", "Q7", "S4", "S5", "Tt"], 
"Bajaj": ["Tempo Trax 10 Str"], 
"Bmw": ["1 Series", "3 Series", "5 Series", "6 Series", "Mini Cooper", "X1 Series", "X3 Series", "X5 Series", "X6 Series", "Z4"], 
"Chevrolet": ["Aveo", "Beat", "Captiva", "Cruze", "Enjoy", "Optra", "Sail", "Spark", "Srv", "Trailblazer"], 
"Datsun": ["Go", "Go Plus", "Redi Go"], 
"Eicher Polaris": ["Multix"], 
"Fiat": ["Abarth", "Avventura", "Grande Punto", "Linea", "Palio", "Palio Stile", "Punto", "Stile Multijet"], 
"Force Motors": ["Force One", "Gurkha"], 
"Ford": ["Ecosport", "Endeavour", "Fiesta", "Figo", "Figo Aspire", "Fusion", "Ikon", "Mondeo"],
"Hindustan Motors": ["Ambassador"], 
"Honda": ["Accord", "Amaze", "Br-v", "Brio", "City", "Civic", "Crv", "Jazz", "Mobilio", "Wr-v"], 
"Hyundai": ["Accent", "Creta", "Elantra", "Elite I20", "Eon", "Fluidic Elantra", "Fluidic Verna", "Getz", "Getz Prime", "Grand I10", "I10", "I20", "Santa Fe", "Santro", "Santro Xing", "Sonata", "Terracan", "Tucson", "Verna", "Xcent"], 
"Isuzu": ["D-max", "Mu7", "Mux"], 
"Jeep": ["Compass", "Grand Cherokee", "Wrangler "], 
"Mahindra": ["Bolero", "Cl 550", "Kuv100", "Nuvosport", "Quanto", "Scorpio", "Ssangyong Rexton", "Supro", "Thar", "Tuv300", "Verito", "Xuv 500", "Xylo"], 
"Mahindra Renault": ["Logan"], 
"Maruti": ["800", "1000", "Alto", "Alto 800", "Alto K10", "Astar", "Baleno", "Celerio", "Ciaz", "Eeco", "Ertiga", "Esteem", "Grand Vitara", "Gypsy", "Ignis", "Kizashi", "Omni", "Ritz", "S-cross", "Stingray", "Swift", "Swift Dzire", "Sx4", "Versa", "Vitara Brezza", "WagonR", "Zen", "Zen Estilo"],
 "Mercedes": ["A-class", "B-class", "C-class", "Cla Class", "E-class", "Gl Class ", "Gla Class", "Glc-class", "Gle-class", "Ml Class", "R Class", "Sl Class", "Slc Class", "Slk Class", "W203c220 Cdi"], 
"Nissan": ["Evalia", "Micra", "Sunny", "Teana", "Terrano", "X-trail"], 
"Opel": ["Astra", "Corsa"], 
"Pal": ["Peugeot"], 
"Premier": ["Rio"], 
"Renault": ["Captur", "Duster", "Fluence", "Koleos", "Kwid", "Lodgy", "Pulse", "Scala"], 
"Skoda": ["Fabia", "Kodiaq", "Laura", "Octavia", "Octavia Combi", "Rapid", "Superb", "Yeti"], 
"Tata": ["Aria", "Bolt", "Hexa", "Indica", "Indica Vista", "Indigo", "Indigo Cs", "Indigo Ecs", "Indigo Manza", "Indigo Marina", "Indigo V Series", "Indigo Xl", "Nano", "Safari", "Safari Dicor", "Tiago", "Tigor", "Zest"], 
"Toyota": ["Camry", "Corolla", "Corolla Altis", "Estima At", "Etios", "Etios Cross", "Etios Liva", "Fortuner", "Innova", "Platinum Etios"], 
"Volkswagen": ["Ameo", "Beetle ", "Caravelle Trendline", "Cross Polo", "Gti1.8 Tsi", "Jetta", "Passat", "Polo", "Tiguan", "Vento"],
"Others":["Others"]
}


window.onload = function () {
	
	//Get html elements

	var makeSel = document.getElementById("makeSel");
	var modelSel = document.getElementById("modelSel");
	
	//Load make
	for (var make in makeModelInfo) {
		makeSel.options[makeSel.options.length] = new Option(make,make);
	}
	
	//make Changed
	makeSel.onchange = function () {
		 
		 modelSel.length = 1; // remove all options bar first
		 
		 if (this.selectedIndex < 1)
			 return; // done
		var model = makeModelInfo[this.value];
		for (var i = 0; i < model.length; i++) {
			modelSel.options[modelSel.options.length] = new Option(model[i], model[i]);
		}
	}
}
